package BMI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputInfo {

	static BufferedReader reader;


	static void init(){
		reader = new BufferedReader(new InputStreamReader(System.in));

	}

	static void  showInputMsg(String str)  {
		System.out.println("");
		System.out.println(str + "を入力してください。");
	}

	static String inputStr() throws IOException{
		String inputStr = reader.readLine();
		return inputStr;
	}

	static int  inputInt() throws IOException{
		String inputStr = reader.readLine();
		int inputInt = Integer.parseInt(inputStr);
		return inputInt;
	}

	static double  inputDouble() throws IOException{
		String inputStr = reader.readLine();
		double inputDouble = Double.parseDouble(inputStr);
		return inputDouble;
	}
}
