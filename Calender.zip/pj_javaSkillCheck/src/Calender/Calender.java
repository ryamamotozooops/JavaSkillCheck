package Calender;

import java.util.ArrayList;
import java.util.Scanner;

public class Calender {
	private int selectYear;
	private int selectMonth;
	ArrayList <Integer> months = new ArrayList<>();
	
	public Calender(int selectYear,int selectMonth) {
		this.selectYear = selectYear;
		this.selectMonth = selectMonth;
		
		months.add(2);
		months.add(4);
		months.add(6);
		months.add(9);
		months.add(11);
	}
	
	
	
	public boolean isLeapYear() {
		boolean isLeapYear = false;
		if(selectYear % 4 == 0) {
			if(selectYear % 100 != 0) {
				return true;
			}
			else if(selectYear % 100 == 0 && selectYear % 400 == 0) {
				return true;
			}
		}
		return isLeapYear;
	}
	
	/*
	 * 選択した月の1日をその年の何日目か計算する
	 */
	
	public int calcYearDays() {
		int days = 0;
		for(int i = 1; i < selectMonth; i++) {
			if(this.months.contains(i)) {
				if(i == 2) {
					if(this.isLeapYear()) {
						days += 29;
					}
					else {
						days += 28;
					}
				}
				else {
					days += 30;
				}
			}
			else {
				days += 31;
			}
		}
		return days+1;
		
	}
	
	/**
	 * 1年1月1日から去年の終わりまで何日過ぎたか計算
	 * @return
	 */
	public int calcStartDays() {
		//うるう年の回数
		int leapYear = ((this.selectYear - 1) / 4) - ((this.selectYear - 1) / 100) + ((this.selectYear - 1) / 400);
		//System.out.println(leapYear);
		return (((selectYear - 1) - leapYear) * 365) + (leapYear * 366);
	}
	
	/**
	 * カレンダーの表示
	 * @param yearDays
	 * @param monthDay
	 */
	public void showCalender(int yearDays,int monthDay) {
		System.out.println("日 月 火 水 木 金 土  ");
		
		
		int weekDay = yearDays % 7;
		
		for(int i = 0; i < weekDay; i++) {
			System.out.print("   ");
		}
		
		for(int i = 1; i <= monthDay; i++) {
			String day = String.valueOf(i);
			if(i < 10) {
				day += "  ";
			}
			else {
				day += " ";
			}
			
			System.out.print(day);
			
			if((weekDay + i) % 7 == 0) {
				System.out.println();
			}
		}
	}
	
	public static void main(String []args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("年を入力");
		
		int monthDay = 31;
		
		int selectYear = sc.nextInt();
		System.out.println("月を入力");
		int selectMonth = sc.nextInt();
		
		Calender calender = new Calender(selectYear,selectMonth);
		
		if(calender.months.contains(selectMonth)) {
			if(selectMonth == 2) {
				if(calender.isLeapYear()) {
					monthDay = 29;
				}
				else {
					monthDay = 28;
				}
			}
			else {
				monthDay = 30;
			}
		}
		
		if(calender.isLeapYear()) {
			System.out.println("うるう年です");
		}
		else {
			System.out.println("うるう年ではないです");
		}
		System.out.println("日数は"+monthDay);
		
		//System.out.println(calender.calcYearDays());
		//System.out.println(calender.calcStartDays());
		
		calender.showCalender(calender.calcStartDays()+ calender.calcYearDays(),monthDay);
		
		sc.close();
	}
}
