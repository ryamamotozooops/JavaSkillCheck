package q3;

public class Main {

	public static void main(String[] args) {

		System.out.println("FizzBuzz問題を出力します");
		FizzBuzz fizzBuzz = new FizzBuzz();
		fizzBuzz.start();

	}

}
