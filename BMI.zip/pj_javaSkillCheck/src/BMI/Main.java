package BMI;

import java.io.IOException;
import java.util.ArrayList;

public class Main {
	public static void main(String []args) throws IOException {
		InputInfo.init();
		System.out.println("BMI、基礎代謝量、適正体重、肥満度判定のどれを表示しますか？");
		System.out.println("BMI:1");
		System.out.println("基礎代謝量:2");
		System.out.println("適正体重:3");
		System.out.println("肥満度判定:4");
		int menuSelect = InputInfo.inputInt();
		System.out.println("-----------人数を入力--------------");
		int people = InputInfo.inputInt();
		
		ArrayList <PersonalInfo> personalList = new ArrayList<>();
		
		for(int i = 0; i < people; i++) {	
			System.out.println("-----------個人の情報を入力--------------");
			
			System.out.println("名前を入力してください。");
			
			String name = InputInfo.inputStr();
			
			System.out.println("身長(cm)[小数点以下一位まで]を入力してください。");
			double height = InputInfo.inputDouble();
			
			System.out.println("体重(kg)[小数点以下一位まで]を入力してください。");
			double weight = InputInfo.inputDouble();
			
			System.out.println("年齢を入力してください。");
			int age = InputInfo.inputInt();
			
			int sex = 0;
			System.out.println("性別(男性:1、女性:2)を入力してください。");
			sex = InputInfo.inputInt();
			PersonalInfo personal = new PersonalInfo(name, age, sex, height, weight);
			personalList.add(personal);
		}
		
		for(PersonalInfo personal : personalList) {
			System.out.println("---- "+ personal.getName() + "さんの情報----");
			System.out.println("身長:"+ personal.getHeight() + "cm");
			System.out.println("体重:"+ personal.getWeight() + "kg");
			System.out.println("年齢:"+ personal.getAge() +"歳");
			System.out.println("性別: "+ personal.getSex());
			
			if(menuSelect == 1) {
				System.out.println("BMI:"+ String.format("%.2f",personal.getBmi()));
			}
			
			if(menuSelect == 2) {
				System.out.println("適正体重:" + String.format("%.2f",personal.getSafeWaight()) + "kg");
			}
			if(menuSelect == 3) {
				System.out.println("基礎代謝:" + String.format("%.2f",personal.getBmr()));
			}
			if(menuSelect == 4) {
				System.out.println("肥満度判定:" + personal.getObesity() );
			}
			System.out.println("----------------------------------------");
		}
	}

}
