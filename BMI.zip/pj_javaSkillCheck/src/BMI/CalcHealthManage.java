package BMI;

public class CalcHealthManage {
	
	public double calcBMI(double height,double waight) {
		return waight / ((height / 100) * (height / 100));
	}
	
	public double calcSafeWaight(double height) {
		return ((height / 100) * (height / 100)) * 22;
	}
	
	public double calcBMR(double height, double weight, int age, String sex) {
		if(sex.equals("男")) {
			return (13.397 * weight) + (4.799 * height) - (5.677 * age) + 88.362;
		}else {
			return (9.247 * weight) + (3.098 * height) - (4.33 * age) + 447.593;
		}
	}
	
	public String calcObesity(double bmi) {
		if(bmi < 18.5) {
			return "低体重(痩せ型)";
		}
		else if(18.5 <= bmi && bmi < 25) {
			return "標準体重";
		}
		else if(25 <= bmi && bmi < 30) {
			return "肥満(1度)";
		}
		else if(30 <= bmi && bmi < 35) {
			return "肥満(2度)";
		}
		else if(35 <= bmi && bmi < 40) {
			return "肥満(3度)";
		}
		else {
			return "肥満(4度)";
		}
			
	}

}
