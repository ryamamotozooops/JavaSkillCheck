package BMI;

public class PersonalInfo {

	private String name;
	private int age;
	private String sex;
	private double weight;
	private double height;
	private double bmi;
	private double safeWaight;
	private double bmr;
	private String obesity;
	public PersonalInfo(String name,int age,int sex,double height,double weight) {
		this.name = name;
		this.age = age;
		if(sex == 1) {
			this.sex = "男";
		}else {
			this.sex = "女";
		}
		this.height = height;
		this.weight = weight;
		CalcHealthManage calc = new CalcHealthManage();
		this.bmi = calc.calcBMI(this.height, this.weight);
		this.safeWaight = calc.calcSafeWaight(this.height);
		this.bmr = calc.calcBMR(this.height, this.weight, this.age, this.sex);
		this.obesity = calc.calcObesity(this.bmi);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getBmi() {
		return bmi;
	}

	public double getSafeWaight() {
		return safeWaight;
	}

	public double getBmr() {
		return bmr;
	}

	public String getObesity() {
		return obesity;
	}
}
