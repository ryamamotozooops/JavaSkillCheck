package q1;

/**
 * 1-100の数字を連続で出力する
 * ただし、3の倍数の時はFizz、5の倍数のときはBuzz、両方の条件を満たすときにはFizzBuzzとコンソールに表示するようにしなさい
 * なお、print文の利用は1度のみとする
 * */
public class FizzBuzzMain {

	public static void main(String[] args) {
		String fbNum = "";
		for (int i = 1; i <= 100; i++) {
			fbNum = String.valueOf(i);
			if(i % 3 == 0  && i % 5 == 0) {
				fbNum = "FizzBuzz";
			}
			else if(i % 3 == 0) {
				fbNum = "Fizz";
			}
			else if(i % 5 == 0) {
				fbNum = "Buzz";
			}
			System.out.println(fbNum);
		}

	}

}
